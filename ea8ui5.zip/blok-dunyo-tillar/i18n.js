/* Blok Dunyo — tillar: o'zbekcha (uz), English (en), qaraqalpaqsha (kaa).
   index.html yonida turadi va undan oldin yuklanadi. */
(function () {
  'use strict';
  var STORE = 'blokdunyo:lang';
  var LANGS = [
    { c: 'uz', n: 'O\u02bbzbekcha', short: 'UZ' },
    { c: 'en', n: 'English', short: 'EN' },
    { c: 'kaa', n: 'Qaraqalpaqsha', short: 'QA' }
  ];
  /* Kalit — o'zbekcha matn. Apostrof turlari tenglashtiriladi (norm). */
  var D = {
    /* --- umumiy --- */
    "Blox Dunyo - Bepul Onlayn O'yinlar": { en: 'Blox Dunyo - Free Online Games', kaa: 'Blox D\u00fanya - Tegin onlayn oy\u0131nlar' },
    "Do'kon": { en: 'Shop', kaa: 'D\u00fakan' },
    "Kiyimim": { en: 'My outfit', kaa: 'Kiyimim' },
    "Tangalar": { en: 'Coins', kaa: 'T\u0131y\u0131nlar' },
    "tanga": { en: 'coins', kaa: 't\u0131y\u0131n' },
    "Qidirish": { en: 'Search', kaa: 'Izlew' },
    "Narsani qidiring": { en: 'Search for items', kaa: 'Zatt\u0131 izle\u0144' },
    "3D avatar bu qurilmada ishlamadi.": { en: "3D avatar isn't available on this device.", kaa: '3D avatar bul qur\u0131lmada islemeydi.' },
    "Panelni ochish yoki yopish": { en: 'Open or close the panel', kaa: 'Paneldi ash\u0131w yamasa jaw\u0131w' },
    "Bosh": { en: 'Home', kaa: 'Bas bet' },
    "Reyting": { en: 'Ranking', kaa: 'Reyting' },
    "Do'stlar": { en: 'Friends', kaa: 'Doslar' },
    "Men": { en: 'Me', kaa: 'Men' },
    "Orqaga": { en: 'Back', kaa: 'Artqa' },
    "O'ynash": { en: 'Play', kaa: 'Oy\u0131naw' },
    "Tez orada": { en: 'Coming soon', kaa: 'Tez arada' },
    "Xush kelibsiz!": { en: 'Welcome!', kaa: 'Xosh keldi\u0144iz!' },
    "marta o'ynalgan": { en: 'plays', kaa: 'm\u00e1rte oynal\u01f5an' },
    "Reyting shu qurilmadagi o'ynashlar soniga qarab tuziladi.": {
      en: 'The ranking is based on how many times each game was played on this device.',
      kaa: 'Reyting us\u0131 qur\u0131lmada\u01f5\u0131 oy\u0131nlar san\u0131na qarap d\u00faziledi.'
    },
    /* --- do'kon --- */
    "Hammasi": { en: 'All', kaa: 'Barl\u0131\u01f5\u0131' },
    "Teri": { en: 'Skin', kaa: 'Teri' },
    "Ko'ylak": { en: 'Shirt', kaa: 'K\u00f3ylek' },
    "Shim": { en: 'Pants', kaa: 'Sh\u0131m' },
    "Fon": { en: 'Background', kaa: 'Fon' },
    "Qalpoq": { en: 'Hat', kaa: 'Qalpaq' },
    "Blok Dunyo": { en: 'Blok Dunyo', kaa: 'Blok D\u00fanya' },
    "Ustalar jamoasi": { en: 'Masters team', kaa: 'Ustalar jamaas\u0131' },
    "Namuna": { en: 'Sample', kaa: '\u00dalti' },
    "Sizniki": { en: 'Yours', kaa: 'Sizdiki' },
    "Kiyilgan": { en: 'Wearing', kaa: 'Kiyilgen' },
    "Sizga tavsiya": { en: 'Recommended for you', kaa: 'Sizge us\u0131n\u0131s' },
    "Uslublarni ko'ring": { en: 'Browse styles', kaa: 'Stillerdi k\u00f3ri\u0144' },
    "Kiyimlarim": { en: 'My clothes', kaa: 'Kiyimlerim' },
    "Yashirish": { en: 'Hide', kaa: 'Jas\u0131r\u0131w' },
    "Bu yerda hali hech narsa yo'q. Do'kondan xarid qiling.": {
      en: 'Nothing here yet. Buy something in the shop.',
      kaa: 'Bul jerde ele hesh n\u00e1rse joq. D\u00fakannan sat\u0131p al\u0131\u0144.'
    },
    "Hech narsa topilmadi.": { en: 'Nothing found.', kaa: 'Hesh n\u00e1rse tab\u0131lmad\u0131.' },
    "Kiyish": { en: 'Wear', kaa: 'Kiyiw' },
    "Sotib olish": { en: 'Buy', kaa: 'Sat\u0131p al\u0131w' },
    "Tanga yetmaydi": { en: 'Not enough coins', kaa: 'T\u0131y\u0131n jetpeydi' },
    "Yangi o'yinlar": { en: 'New games', kaa: 'Ja\u0144a oy\u0131nlar' },
    /* --- buyumlar --- */
    "Och": { en: 'Light', kaa: 'Ash\u0131q' },
    "Bug'doy": { en: 'Wheat', kaa: 'Biday' },
    "Qumli": { en: 'Sandy', kaa: 'Quml\u0131' },
    "Qoramtir": { en: 'Dark', kaa: 'Qara\u0144\u01f5\u0131law' },
    "Qora": { en: 'Black', kaa: 'Qara' },
    "Feruza": { en: 'Turquoise', kaa: 'Feruza' },
    "Qizil": { en: 'Red', kaa: 'Q\u0131z\u0131l' },
    "Moviy": { en: 'Blue', kaa: 'K\u00f3k' },
    "Sariq": { en: 'Yellow', kaa: 'Sar\u0131' },
    "Binafsha": { en: 'Purple', kaa: 'Binafsha' },
    "Oq": { en: 'White', kaa: 'Aq' },
    "Yashil": { en: 'Green', kaa: 'Jas\u0131l' },
    "Kulrang": { en: 'Grey', kaa: 'K\u00falre\u0144' },
    "Ko'k": { en: 'Blue', kaa: 'K\u00f3k' },
    "Xaki": { en: 'Khaki', kaa: 'Xaki' },
    "Sokin": { en: 'Calm', kaa: 'T\u0131n\u0131sh' },
    "Tong": { en: 'Dawn', kaa: 'Ta\u0144' },
    "Okean": { en: 'Ocean', kaa: 'Okean' },
    "O'rmon": { en: 'Forest', kaa: 'To\u01f5ay' },
    "Kecha": { en: 'Night', kaa: 'T\u00fan' },
    "Oddiy": { en: 'Plain', kaa: '\u00c1piway\u0131' },
    "Yo'q": { en: 'None', kaa: 'Joq' },
    "Kepka": { en: 'Cap', kaa: 'Kepka' },
    "Silindr": { en: 'Top hat', kaa: 'Tsilindr' },
    "Tojcha": { en: 'Crown', kaa: 'T\u00e1j' },
    /* --- o'yinlar --- */
    "Blok Studiya": { en: 'Blok Studio', kaa: 'Blok Studiya' },
    "Sakrash yo'li": { en: 'Jump Path', kaa: 'Sekiriw jol\u0131' },
    "Blok poygasi": { en: 'Block Race', kaa: 'Blok jar\u0131s\u0131' },
    "O'z dunyongni qur: bloklar qo'y, skript yoz, avatar bilan yugur.": {
      en: 'Build your own world: place blocks, write scripts, run as your avatar.',
      kaa: '\u00d3z d\u00fanya\u0144d\u0131 qur: bloklar qoy, skript jaz, avatar menen j\u00fagir.'
    },
    "Joystick bilan 3D platformalardan sakrab, marraga yeting.": {
      en: 'Jump across 3D platforms with the joystick and reach the finish.',
      kaa: 'Joystik penen 3D platformalardan sekirip, maqsetke jeti\u0144.'
    },
    "Bu o'yin hali yaratilmagan.": { en: "This game hasn't been made yet.", kaa: 'Bul oy\u0131n ele jarat\u0131lma\u01f5an.' },
    /* --- promokod --- */
    "Promokod": { en: 'Promo code', kaa: 'Promokod' },
    "Olish": { en: 'Redeem', kaa: 'Al\u0131w' },
    "Masalan: BLOKDUNYO": { en: 'For example: BLOKDUNYO', kaa: 'M\u0131sal\u0131: BLOKDUNYO' },
    "Promokodni yozing": { en: 'Enter a promo code', kaa: 'Promokodt\u0131 jaz\u0131\u0144' },
    "Bu promokod allaqachon ishlatilgan": { en: 'This promo code has already been used', kaa: 'Bul promokod bur\u0131n isletilgen' },
    "Bunday promokod topilmadi": { en: 'No such promo code', kaa: 'Bunday promokod tab\u0131lmad\u0131' },
    "Ilova hali yuklanmadi, sahifani yangilang": { en: "The app hasn't loaded yet, refresh the page", kaa: 'Ilova ele j\u00faklenbegen, betti ja\u0144ala\u0144' },
    "Tayyor!": { en: 'Done!', kaa: 'Tay\u0131n!' },
    "tanga qo'shildi": { en: 'coins added', kaa: 't\u0131y\u0131n qos\u0131ld\u0131' },
    /* --- do'stlar --- */
    "Do'st qo'shish": { en: 'Add friend', kaa: 'Dos qos\u0131w' },
    "Do'st qo'shishish": { en: 'Add friend', kaa: 'Dos qos\u0131w' },
    "Ro'yxatdan o'tish": { en: 'Sign up', kaa: 'Dizimnen \u00f3tiw' },
    "Kirish": { en: 'Sign in', kaa: 'Kiriw' },
    "Do'stlar bilan o'ynash uchun hisob kerak. Faqat nom va parol so'raladi.": {
      en: 'You need an account to play with friends. Only a name and password are asked.',
      kaa: 'Doslar menen oynaw ush\u0131n akkaunt kerek. Tek at h\u00e1m parol sor\u0131lad\u0131.'
    },
    "Foydalanuvchi nomi": { en: 'Username', kaa: 'Paydalan\u0131wsh\u0131 at\u0131' },
    "Parol": { en: 'Password', kaa: 'Parol' },
    "masalan: blok_ustasi": { en: 'for example: block_master', kaa: 'm\u0131sal\u0131: blok_ustas\u0131' },
    "kamida 6 belgi": { en: 'at least 6 characters', kaa: 'keminde 6 belgi' },
    "Hisob yaratildi, lekin Supabase'da \u201cConfirm email\u201d o'chirilmagan.": {
      en: 'Account created, but \u201cConfirm email\u201d is not turned off in Supabase.',
      kaa: 'Esep jarat\u0131ld\u0131, biraq Supabase\u2019ta \u201cConfirm email\u201d \u00f3shirilmegen.'
    },
    "Hisob yaratish": { en: 'Create account', kaa: 'Akkaunt jarat\u0131w' },
    "Hisobim bor, kirish": { en: 'I have an account, sign in', kaa: 'Akkaunt\u0131m bar, kiriw' },
    "Hisobim yo'q, ro'yxatdan o'tish": { en: "I don't have an account, sign up", kaa: 'Akkaunt\u0131m joq, dizimnen \u00f3tiw' },
    "Parolni unutsangiz tiklab bo'lmaydi, uni eslab qoling.": {
      en: "If you forget the password it can't be recovered, so remember it.",
      kaa: 'Parold\u0131 um\u0131tsa\u0144\u0131z tiklep bolmayd\u0131, on\u0131 eslep qal\u0131\u0144.'
    },
    "Olib tashlash": { en: 'Remove', kaa: '\u00d3shiriw' },
    "Hali do'stlar yo'q. \u201cDo'st qo'shish\u201d bo'limida nom bo'yicha qidiring.": {
      en: 'No friends yet. Search by name in the "Add friend" tab.',
      kaa: 'Ele doslar joq. "Dos qos\u0131w" b\u00f6liminde at boy\u0131nsha izle\u0144.'
    },
    "Hech kim topilmadi.": { en: 'Nobody found.', kaa: 'Hesh kim tab\u0131lmad\u0131.' },
    "Qo'shish": { en: 'Add', kaa: 'Qos\u0131w' },
    "Do'st": { en: 'Friend', kaa: 'Dos' },
    "Yuborilgan": { en: 'Sent', kaa: 'Jiberilgen' },
    "Qabul": { en: 'Accept', kaa: 'Qab\u0131llaw' },
    "So'rovlar": { en: 'Requests', kaa: 'Sorawlar' },
    "Rad": { en: 'Decline', kaa: 'Bas tart\u0131w' },
    "Bekor": { en: 'Cancel', kaa: 'Biykar etiw' },
    "Do'stingizning nomini yozing (kamida 3 harf).": {
      en: "Type your friend's name (at least 3 letters).",
      kaa: 'Dos\u0131\u0144\u0131zd\u0131\u0144 at\u0131n jaz\u0131\u0144 (keminde 3 h\u00e1rip).'
    },
    "Odamlarni qidirish": { en: 'Search people', kaa: 'Adamlard\u0131 izlew' },
    "Hisobingiz": { en: 'Your account', kaa: 'Esep\u0131\u0144\u0131z' },
    "Chiqish": { en: 'Sign out', kaa: 'Sh\u0131\u01f5\u0131w' },
    "Server hali sozlanmagan.": { en: "The server isn't set up yet.", kaa: 'Server ele sazlanba\u01f5an.' },
    "Nom yoki parol no'to'g'ri": { en: 'Wrong name or password', kaa: 'At yamasa parol q\u00e1te' },
    "Bu nom band": { en: 'This name is taken', kaa: 'Bul at b\u00e1nt' },
    "Parol kamida 6 belgi bo'lsin": { en: 'Password must be at least 6 characters', kaa: 'Parol keminde 6 belgiden bols\u0131n' },
    "Juda ko'p urinish. Birozdan keyin qayta urinib ko'ring": {
      en: 'Too many attempts. Try again in a moment.',
      kaa: 'J\u00fad\u00e1 k\u00f3p ur\u0131n\u0131s. Az\u0131raqtan keyin qayta ur\u0131n\u0131\u0144.'
    },
    "Internet yo'q yoki server javob bermadi": { en: "No internet, or the server didn't answer", kaa: 'Internet joq yamasa server jawap bermedi' },
    "Nom 3\u201316 belgi: a\u2013z, 0\u20139, _": { en: 'Name 3-16 characters: a-z, 0-9, _', kaa: 'At 3\u201316 belgi: a\u2013z, 0\u20139, _' },
    "So'rov allaqachon bor yoki siz do'stsiz": { en: "A request already exists, or you're already friends", kaa: 'Soraw bur\u0131n bar yamasa siz doslars\u0131z' },
    "So'rov yuborildi": { en: 'Request sent', kaa: 'Soraw jiberildi' }
  };

  function norm(s) {
    return String(s).replace(/[\u02bb\u02bc\u2018\u2019\u2032`\u00b4']/g, "'").replace(/\s+/g, ' ').trim();
  }
  function known(c) { for (var i = 0; i < LANGS.length; i++) if (LANGS[i].c === c) return true; return false; }

  var cur = null;
  try { var saved = localStorage.getItem(STORE); if (saved && known(saved)) cur = saved; } catch (e) {}
  if (!cur) {
    var nl = String(navigator.language || 'uz').toLowerCase();
    cur = nl.indexOf('kaa') === 0 || nl.indexOf('kar') === 0 ? 'kaa' : nl.indexOf('en') === 0 ? 'en' : 'uz';
  }

  var listeners = [];
  function T(s) {
    if (cur === 'uz' || s == null) return s;
    var e = D[norm(s)];
    return e && e[cur] ? e[cur] : s;
  }
  function short(c) { for (var i = 0; i < LANGS.length; i++) if (LANGS[i].c === c) return LANGS[i].short; return 'UZ'; }

  function applyStatic() {
    document.documentElement.lang = cur;
    var t = document.querySelector('title');
    if (t) t.textContent = T(t.getAttribute('data-i18n-base') || t.textContent);
    var els = document.querySelectorAll('[data-i18n]');
    for (var i = 0; i < els.length; i++) {
      var el = els[i], k = el.getAttribute('data-i18n');
      if (!k) continue;
      el.textContent = T(k);
    }
    var ph = document.querySelectorAll('[data-i18n-ph]');
    for (var j = 0; j < ph.length; j++) ph[j].setAttribute('placeholder', T(ph[j].getAttribute('data-i18n-ph')));
    var ar = document.querySelectorAll('[data-i18n-aria]');
    for (var k2 = 0; k2 < ar.length; k2++) ar[k2].setAttribute('aria-label', T(ar[k2].getAttribute('data-i18n-aria')));
  }

  function injectCss() {
    if (document.getElementById('i18n-css')) return;
    var st = document.createElement('style');
    st.id = 'i18n-css';
    st.textContent =
      '#nav i{font-style:normal}' +
      '#lang{background:var(--surface);border-radius:999px;min-width:46px;padding:4px 10px;font-size:13px;font-weight:700;display:flex;align-items:center;justify-content:center;gap:4px;box-shadow:0 1px 3px rgba(0,0,0,.15)}' +
      '#lang .gl{font-size:14px;font-weight:400}' +
      '#langmenu{position:absolute;right:8px;top:calc(100% - 6px);background:var(--surface);border-radius:14px;padding:6px;box-shadow:0 10px 30px rgba(0,0,0,.28);display:flex;flex-direction:column;gap:2px;z-index:40;min-width:180px}' +
      '#langmenu button{background:none;text-align:left;border-radius:10px;min-height:44px;justify-content:flex-start;padding:0 12px;font-weight:600}' +
      '#langmenu button[aria-current="true"]{background:var(--raised)}';
    document.head.appendChild(st);
  }

  function buildSwitch() {
    injectCss();
    var top = document.getElementById('top');
    if (!top || document.getElementById('lang')) return;
    var btn = document.createElement('button');
    btn.id = 'lang';
    btn.type = 'button';
    btn.setAttribute('aria-haspopup', 'true');
    btn.setAttribute('aria-expanded', 'false');
    btn.setAttribute('aria-label', 'Til / Language');
    btn.innerHTML = '<span class="gl" aria-hidden="true">\u25cb</span><span id="langc">' + short(cur) + '</span>';
    var menu = document.createElement('div');
    menu.id = 'langmenu';
    menu.className = 'off';
    menu.setAttribute('role', 'menu');
    menu.innerHTML = LANGS.map(function (l) {
      return '<button type="button" role="menuitem" data-lang="' + l.c + '"' + (l.c === cur ? ' aria-current="true"' : '') + '>' + l.n + '</button>';
    }).join('');
    var sbtn = document.getElementById('sbtn');
    if (sbtn && sbtn.parentNode === top) top.insertBefore(btn, sbtn); else top.appendChild(btn);
    top.appendChild(menu);
    menu.querySelectorAll('[data-lang]').forEach(function (b) { b.setAttribute('lang', b.getAttribute('data-lang')); });
    btn.addEventListener('click', function () {
      var open = menu.classList.toggle('off') === false;
      btn.setAttribute('aria-expanded', open ? 'true' : 'false');
      if (open) menu.querySelector('button').focus();
    });
    menu.addEventListener('click', function (e) {
      var b = e.target.closest('[data-lang]');
      if (b) setLang(b.getAttribute('data-lang'));
    });
    document.addEventListener('click', function (e) {
      if (!menu.classList.contains('off') && !menu.contains(e.target) && e.target !== btn && !btn.contains(e.target)) {
        menu.classList.add('off');
        btn.setAttribute('aria-expanded', 'false');
      }
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && !menu.classList.contains('off')) {
        menu.classList.add('off');
        btn.setAttribute('aria-expanded', 'false');
      }
    });
  }

  function refreshSwitch() {
    var c = document.getElementById('langc');
    if (c) c.textContent = short(cur);
    var menu = document.getElementById('langmenu');
    if (menu) menu.querySelectorAll('[data-lang]').forEach(function (b) {
      if (b.getAttribute('data-lang') === cur) b.setAttribute('aria-current', 'true');
      else b.removeAttribute('aria-current');
    });
  }

  function setLang(c) {
    if (!known(c)) return;
    cur = c;
    try { localStorage.setItem(STORE, c); } catch (e) {}
    var menu = document.getElementById('langmenu');
    if (menu) menu.classList.add('off');
    applyStatic();
    refreshSwitch();
    for (var i = 0; i < listeners.length; i++) { try { listeners[i](c); } catch (e) {} }
    if (typeof window.applyLang === 'function') { try { window.applyLang(); } catch (e) {} }
  }

  window.T = T;
  window.I18N = {
    t: T,
    get lang() { return cur; },
    LANGS: LANGS,
    setLang: setLang,
    applyStatic: applyStatic,
    onChange: function (fn) { if (typeof fn === 'function') listeners.push(fn); }
  };

  function start() {
    var t = document.querySelector('title');
    if (t && !t.getAttribute('data-i18n-base')) t.setAttribute('data-i18n-base', t.textContent);
    buildSwitch();
    applyStatic();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start);
  else start();
})();
